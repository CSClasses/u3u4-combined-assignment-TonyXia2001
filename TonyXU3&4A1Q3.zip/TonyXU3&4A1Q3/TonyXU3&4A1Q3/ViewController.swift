//
//  ViewController.swift
//  TonyXU3&4A1Q3
//
//  Created by Student on 2019-05-21.
//  Copyright © 2019 TonyX. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    @IBAction func doExit(_ sender: Any) {
        exit(0)
    }
    
}

