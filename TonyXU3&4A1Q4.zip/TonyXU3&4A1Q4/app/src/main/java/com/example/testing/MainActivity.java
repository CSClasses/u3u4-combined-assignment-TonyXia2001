package com.example.testing;

import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void setPercentage(View v) {
        EditText percentage = (EditText) findViewById(R.id.percentage);
        switch (v.getId()) {
            case (R.id.fifteen):
                percentage.setText("15");
                break;
            case (R.id.twenty):
                percentage.setText("20");
                break;
        }

    }

    public void calculate(View view) {
        EditText total = (EditText)findViewById(R.id.total);
        EditText percentage = (EditText) findViewById(R.id.percentage);
        String totalAmount = total.getText().toString();
        String percentageTip = percentage.getText().toString();
        TextView display = (TextView) findViewById(R.id.display);
        if (totalAmount.isEmpty() || percentageTip.isEmpty()) {
            String errorMsg = "Please specify both the total amount and the percentage!";
            display.setText(errorMsg);
        } else {
            double price = Double.parseDouble(totalAmount);
            int tip = Integer.parseInt(percentageTip);
            double answer = price + Math.round((price * tip))/100.0;
            String outputText = "You should pay $" + answer;
            display.setText(outputText);
        }
    }

}
